#include<stdio.h>

	int main()
	{
		int num;
		printf("Enter a number\n");
		scanf("%d",&num);
		printf("Decimal :%d\n",num)	;
//		printf("%f\n",num);
		printf("Hex :%x\n",num);
		printf("Octal :%o\n",num);
		printf("Char :%c\n",num);
		return 0;
	}
