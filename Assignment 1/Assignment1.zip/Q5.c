#include<stdio.h>

	int main()
	{
		printf("\\n=%d\n",'\n');
		printf("\\r=%d\n",'\r');
		printf("\\t=%d\n",'\t');
		printf("\\a=%d\n",'\a');
		printf("\\b=%d\n",'\b');
			return 0;
	}
