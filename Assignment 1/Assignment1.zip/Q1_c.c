

#include<stdio.h>

int main()
{
	int a,b,mul;
	printf("Enter 2 Number to Substract:\n");
	scanf("%d %d",&a,&b);
    mul=a*b;
	printf("Difference  of %d and %d is %d",a,b,mul);
	return 0;
}
